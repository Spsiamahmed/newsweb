<?php

namespace App\Policies;

use App\Enums\PostStatus;
use App\Models\Post;
use App\Models\User;
use Illuminate\Support\Facades\Log;

class PostPolicy
{
    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return false;
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, Post $post): bool
    {
        if (!$user->can('view posts')) {
            return false;
        }

        return $user->id === $post->author_id;
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        if (!$user->can('create posts')) {
            return false;
        }

        return true;
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, Post $post): bool
    {
        if (!$user->can('update posts')) {
            Log::info('update not allowed 1');
            return false;
        }

        if (!in_array($post->status, [PostStatus::DRAFT, PostStatus::REJECTED, PostStatus::REVOKED])) {
            return false;
        }

        return $user->id === $post->author_id;
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, Post $post): bool
    {
        if (!$user->can('delete posts')) {
            return false;
        }

        if ($post->status === PostStatus::PUBLISHED) {
            return false;
        }

        return $user->id === $post->author_id;
    }

    /**
     * Determine whether the user can restore the model.
     */
    public function restore(User $user, Post $post): bool
    {
        if (!$user->can('view posts')) {
            return false;
        }

        return $user->id === $post->author_id;
    }

    /**
     * Determine whether the user can permanently delete the model.
     */
    public function forceDelete(User $user, Post $post): bool
    {
        return false;
    }
}
